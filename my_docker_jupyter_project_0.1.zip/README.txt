----------------------------------------------------------------------------------------------------------------------------
22.11.19 Friday 11:38am
----------------------------------------------------------------------------------------------------------------------------
This image is made pursuded by the purpose of moving to the portable independent environment.

The idea is to make it possible to run my projects wherever I am regardless of the specific working station I currently use.
Using scripts I am now able to set up whole environment automatically and run my Python pieces.
----------------------------------------------------------------------------------------------------------------------------

1) Dockerfile : Docker instruction to build up Python Linux-alpine based environment
2) ... 
